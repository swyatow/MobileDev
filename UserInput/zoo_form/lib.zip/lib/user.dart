import 'package:zoo_form/regForm.dart';

class User {
  String name = "";
  String? phone;
  String email = "";
  String? country;
  int age = 0;
  Gender gender = Gender.male;
  String? about;
  String? station;
}
